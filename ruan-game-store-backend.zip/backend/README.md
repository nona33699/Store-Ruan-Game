# Ruan Game Store — Backend (Fase 1)

Catálogo dinâmico + carrinho de compras funcional. Sem Pix automático e sem
painel admin ainda — isso vem nas próximas fases.

## O que já funciona
- Lista de produtos vinda de um banco de dados (SQLite), não mais fixa no HTML
- Adicionar/remover itens do carrinho
- Finalizar pedido (fica salvo no banco como "pendente", sem pagamento
  automático ainda — você confirma manualmente pelo Discord, como já faz hoje)

## Como rodar (via Replit, direto do navegador)

1. Sobe essa pasta inteira num repositório novo no GitHub (mesmo processo que
   você já usa: criar repositório, "Add file" → "Upload files", ou git
   add/commit/push pelo Termux)
2. Entra em [replit.com](https://replit.com) e cria uma conta grátis
3. "Create Repl" → aba **"Import from GitHub"** → cola o link do repositório
4. O Replit detecta que é um projeto Node.js automaticamente
5. Clica no botão verde **"Run"**
6. Vai abrir uma prévia do site dentro do Replit, com uma URL pública
   (algo tipo `nome-do-repl.usuario.repl.co`)

## Estrutura
- `server.js` — servidor principal (rotas da loja e do carrinho)
- `db/init.js` — cria o banco de dados e cadastra os produtos iniciais
- `views/index.ejs` — página da loja
- `public/style.css` — visual (tema vermelho/preto)

## Próximas fases
- **Fase 2**: gerar Pix automático no checkout
- **Fase 3**: painel admin com senha pra cadastrar/editar produtos e estoque
- **Fase 4**: sistema de afiliados
